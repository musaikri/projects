package com.cg.paymentwalletspring.repo;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.paymentwalletspring.dto.Customer;

@Repository("paymentwallet")
public interface PaymentWalletRepo extends CrudRepository<Customer,String>{
	
}
