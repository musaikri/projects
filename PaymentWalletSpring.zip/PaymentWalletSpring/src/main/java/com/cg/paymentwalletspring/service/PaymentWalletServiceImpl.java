package com.cg.paymentwalletspring.service;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.paymentwalletspring.dto.Customer;
import com.cg.paymentwalletspring.dto.Wallet;
import com.cg.paymentwalletspring.exception.PaymentWalletException;
import com.cg.paymentwalletspring.repo.PaymentWalletRepo;


@Service
public class PaymentWalletServiceImpl implements PaymentWalletService{
@Autowired
private PaymentWalletRepo repo; 
	@Override
	public Customer withdrawMoney(String phone, BigDecimal balance) {
		
		Customer cust=repo.findById(phone).get();
		BigDecimal money= cust.getWallet().getBalance();
		BigDecimal update=money.subtract(balance);
		 cust.getWallet().setBalance(update);
		Customer dto= repo.save(cust);
		
		return dto;
	}
	@Override
	public Customer showBalance(String phone)  {
		Customer cust=repo.findById(phone).get();
		return cust;
	}
	
	
	@Override
	public String printTransaction(String phone) {
		Customer cust=repo.findById(phone).get();
		if(cust!=null)
		{
		String str=cust.getStatement();
		return str;
		}
		return null;
	}
	@Override
	public  Customer fundTransfer(String sourcePhone, String targetPhone, BigDecimal balance)
		 {
		Customer cust=withdrawMoney(sourcePhone,balance);
		Customer cust1=depositMoney(targetPhone,balance);
		if(cust!=null&&cust1!=null)
		{
		return cust;
		}
		return null;
	}
	@Override
	public Customer depositMoney(String phone, BigDecimal balance) {
		Customer cust=repo.findById(phone).get();
		BigDecimal money= cust.getWallet().getBalance();
		BigDecimal update=balance;/*money.add(balance);*/
		 cust.getWallet().setBalance(update);
		Customer dto= repo.save(cust);
		return dto;
	}
	
	
	@Override
	public boolean checkLogin(String number, String password) {
		boolean status=false;
		Customer cust=repo.findById(number).get();
		if(cust.getWallet().getPassword().equals(password))
		{
			status=true;
			return status;
		}
		return status;
	}
	
	

	@Override
	public boolean validatePhone(String phoneNumber) throws PaymentWalletException {
		String pattern = "\\d{10}";
		if (!(phoneNumber.matches(pattern))) {
			throw new PaymentWalletException("enter valid phone number");
		}
		return true;
	}
	@Override
	public boolean validateMoney(BigDecimal balance) throws PaymentWalletException {
		String amou = balance.toString();
		if (!(amou.matches("\\d+"))) {
			throw new PaymentWalletException("enter valid money");
		}
		return true;
	}
	@Override
	public boolean validateAge(Integer age) throws PaymentWalletException {
		String age1 = age.toString();
		if (!(age1.matches("\\d{2}"))) {
			throw new PaymentWalletException("enter valid age");
		}
		return true;
	}
	@Override
	public boolean validateGender(String gender) throws PaymentWalletException {
		if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("m")) {
			return true;
		} else if (gender.equalsIgnoreCase("female")
				|| gender.equalsIgnoreCase("f")) {
			return true;
		} else {
			throw new PaymentWalletException("enter valid gender");
		}
	}
	@Override
	public boolean validateName(String name) throws PaymentWalletException {
		if (!(name.matches("[a-zA-Z]+"))) {
			throw new PaymentWalletException("enter valid name");
		}
		return true;
	}
	@Override
	public boolean validateEmail(String emailId) throws PaymentWalletException {
		if (!(emailId.matches("[a-zA-Z0-9.]+@[a-zA-Z]+.[a-zA-Z]{2,}"))) {
			throw new PaymentWalletException("enter valid email");
		}
		return true;
	}
	@Override
	public boolean validatePassword(String pass) throws PaymentWalletException {
		if (!((pass.length()) >= 8)) {
			throw new PaymentWalletException("enter correct password");
		}
		return true;
	}
	@Override
	public Customer registerCustomer(Customer customer)
			 {
		
		Customer cust=repo.save(customer);
		return cust;
	}

	
}
	
