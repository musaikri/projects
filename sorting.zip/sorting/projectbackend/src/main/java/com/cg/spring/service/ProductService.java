package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.Product;
import com.cg.spring.dao.ProductDao;

@Service
@Transactional
public class ProductService implements IProductService {

	@Autowired
	ProductDao repo;

	@Override
	public List<Product> showProducts() {

		return repo.showProducts();
	}

	@Override
	public List<Product> LowToHigh() {

		return repo.LowToHigh();
	}

	@Override
	public List<Product> HighToLow() {

		return repo.HighToLow();
	}

	public List<Product> BestSeller() {
		return repo.BestSeller();
	}

	public List<Product> MostViewed() {
		return repo.MostViewed();
	}

	public List<Product> Range(int min, int max) {
		return repo.Range(min, max);
	}

	@Override
	public List<Product> getBySearch(String pro) {
		return repo.getBySearch(pro);
	}
}
