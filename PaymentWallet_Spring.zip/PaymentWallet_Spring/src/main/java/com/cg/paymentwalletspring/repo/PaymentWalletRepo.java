package com.cg.paymentwalletspring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.paymentwalletspring.dto.Customer;

@Repository("paymentwalletrepo")
public interface PaymentWalletRepo extends CrudRepository<Customer, String> {

}
