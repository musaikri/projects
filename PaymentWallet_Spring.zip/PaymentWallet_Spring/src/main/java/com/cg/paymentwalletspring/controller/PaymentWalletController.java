package com.cg.paymentwalletspring.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.paymentwalletspring.dto.Customer;
import com.cg.paymentwalletspring.exception.PaymentWalletException;
import com.cg.paymentwalletspring.service.PaymentWalletService;

@RestController
public class PaymentWalletController {
	@Autowired
	PaymentWalletService service;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public Customer registerCustomer(@RequestBody Customer customer) {
		return service.registerCustomer(customer);

	}

	@RequestMapping(value = "/deposit/{phone}/{amount}", method = RequestMethod.PUT)
	public Customer deposit(@PathVariable String phone, @PathVariable BigDecimal amount) {
		return service.depositMoney(phone, amount);

	}

	@RequestMapping(value = "/withdraw/{phone}/{amount}", method = RequestMethod.PUT)
	public Customer withdraw(@PathVariable String phone, @PathVariable BigDecimal amount) {
		return service.withdrawMoney(phone, amount);

	}

	@RequestMapping(value = "/fundtransfer/{sourcephone}/{targetphone}/{amount}", method = RequestMethod.PUT)
	public Customer fundTransfer(@PathVariable String sourcephone, @PathVariable String targetphone,
			@PathVariable BigDecimal amount) {
		return service.fundTransfer(sourcephone, targetphone, amount);

	}

	@RequestMapping(value = "/showbalance/{phone}", method = RequestMethod.GET)
	public Customer showBalance(@PathVariable String phone) {
		return service.showBalance(phone);

	}

	@RequestMapping(value = "/print/{phone}", method = RequestMethod.GET)
	public String statement(@PathVariable String phone) {
		return service.printTransaction(phone);

	}

	/*@RequestMapping(value = "/logincheck/{phone}/{password}", method = RequestMethod.GET)
	public boolean login(@PathVariable String phone, @PathVariable String password) {
		return service.checkLogin(phone, password);

	}*/

	@RequestMapping(value = "/statement/{phone}", method = RequestMethod.GET)
	public List<String> transactions(@PathVariable String phone) throws PaymentWalletException {
		String string = service.printTransaction(phone);
		Scanner sc = new Scanner(string).useDelimiter("abc");
		String str = null;
		List<String> list = new ArrayList<>();
		while (sc.hasNext()) {
			list.add(sc.next());

		}
		return list;

	}
}
