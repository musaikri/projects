package com.cg.paymentwalletspring.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.paymentwalletspring.dto.Customer;
import com.cg.paymentwalletspring.exception.PaymentWalletException;
import com.cg.paymentwalletspring.repo.PaymentWalletRepo;
@Service("paymentwalletservice")
public class PaymentWalletServiceImpl implements PaymentWalletService{
@Autowired
PaymentWalletRepo dao; 
	
	public Customer withdrawMoney(String phone, BigDecimal balance)  {
		
		Customer cust=dao.findById(phone).get();
		BigDecimal money=cust.getWallet().getBalance();
		BigDecimal update=money.subtract(balance);
		cust.getWallet().setBalance(update);
		Customer dto= dao.save(cust);
		String str=cust.getStatement();
		String withdraw=str.concat("you have withdrawed amount of rupees ".concat(balance.toString()).concat(LocalDateTime.now().toString()).concat("zzz"));
		cust.setStatement(withdraw);
		
		return dto;
	}
	
	public Customer showBalance(String phone)  {
		Customer cust=dao.findById(phone).get();
		return cust;
	}
	
	
	
	public String printTransaction(String phone) {
		Customer cust=dao.findById(phone).get();
		if(cust!=null)
		{
		String str=cust.getStatement();
		return str;
		}
		return null;
	}
	
	public Customer fundTransfer(String sourcePhone, String targetPhone, BigDecimal balance)
		 {
		Customer cust=withdrawMoney(sourcePhone,balance);
		depositMoney(targetPhone,balance);
		return cust;
	}
	
	public Customer depositMoney(String phone, BigDecimal balance)  {
		Customer cust=dao.findById(phone).get();
		BigDecimal money=cust.getWallet().getBalance();
		BigDecimal update=money.add(balance);
		cust.getWallet().setBalance(update);
		Customer dto= dao.save(cust);
		String str=cust.getStatement();
		String deposit=str.concat("you have deposited amount of rupees ".concat(balance.toString()).concat(LocalDateTime.now().toString()).concat("abc"));
		cust.setStatement(deposit);  
		return dto;
	}
	
	
	
	/*public boolean checkLogin(String number, String password) {
		boolean status=false;
		Customer cust=dao.findById(number).get();
		if(cust.getWallet().getPassword().equals(password))
		{
			status=true;
			return status;
		}
		return status;
	}
	
	

	
	public boolean validatePhone(String phoneNumber) throws PaymentWalletException {
		String pattern = "\\d{10}";
		if (!(phoneNumber.matches(pattern))) {
			throw new PaymentWalletException("enter valid phone number");
		}
		return true;
	}

	public boolean validateMoney(BigDecimal balance) throws PaymentWalletException {
		String amou = balance.toString();
		if (!(amou.matches("\\d+"))) {
			throw new PaymentWalletException("enter valid money");
		}
		return true;
	}

	public boolean validateAge(Integer age) throws PaymentWalletException {
		String age1 = age.toString();
		if (!(age1.matches("\\d{2}"))) {
			throw new PaymentWalletException("enter valid age");
		}
		return true;
	}

	public boolean validateGender(String gender) throws PaymentWalletException {
		if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("m")) {
			return true;
		} else if (gender.equalsIgnoreCase("female")
				|| gender.equalsIgnoreCase("f")) {
			return true;
		} else {
			throw new PaymentWalletException("enter valid gender");
		}
	}

	public boolean validateName(String name) throws PaymentWalletException {
		if (!(name.matches("[a-zA-Z]+"))) {
			throw new PaymentWalletException("enter valid name");
		}
		return true;
	}

	public boolean validateEmail(String emailId) throws PaymentWalletException {
		if (!(emailId.matches("[a-zA-Z0-9.]+@[a-zA-Z]+.[a-zA-Z]{2,}"))) {
			throw new PaymentWalletException("enter valid email");
		}
		return true;
	}

	public boolean validatePassword(String pass) throws PaymentWalletException {
		if (!((pass.length()) >= 8)) {
			throw new PaymentWalletException("enter correct password");
		}
		return true;
	}*/

	public Customer registerCustomer(Customer customer)
			 {
		Customer cust=dao.save(customer);
		return cust;
	}

	
}
	
